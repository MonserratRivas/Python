class Biblioteca:
    def __init__(self, lista_libros, lista_user):
        self.lista_libros = lista_libros
        self. lista_user = lista_user
        self.list = []

    def agregar_libro(self):
        self.list.append(agregar_libro)
        return self

    def eliminar_libro_biblioteca(self):
        for x in self.list:
            if x.libro == eliminar_libro_biblioteca:
                x.remove
            else: 
                print("El libro seleccionado no existe. ")
                return self

    def agregar_user(self):
        self.list.append(agregar_user)
        return self

    def eliminar_user(self):
        for y in self.list:
            if y.usuario == eliminar_user:
                y.remove(eliminar_user)
                print(f"El Usuario {usuario} a sido eliminado exitosamente. ")
            else: 
                print("El usuario seleccionado no existe. ")
                return self

    def listar_libros(self):
        if libro == listar_libros:
            listdir()
            return self
        else: 
            print("No hay libros en la Biblioteca. ")

    def listar_usuarios(self):
        for i in range():
            return lista_user