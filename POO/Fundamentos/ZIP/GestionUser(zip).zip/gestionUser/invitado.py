class Invitado:
    def __init__(self, nombre):
        self.nombre = nombre

    def iniciarSesion(self):
        pass