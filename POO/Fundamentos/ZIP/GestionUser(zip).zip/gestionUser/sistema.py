class Sistema:
    def __init__(self):
        self.lista = []

    def listarUsuarios(self):
        for x in range():
            return lista.usuario
            
    def registrarUsuarios(self,usuario):
        self.lista.append(usuario)
